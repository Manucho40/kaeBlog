export default {
    GET_ARTICLES(state,articles){
        state.articles = articles
    },
}