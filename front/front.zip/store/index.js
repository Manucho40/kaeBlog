export const state = () => ({
    articles: [],
  })
  