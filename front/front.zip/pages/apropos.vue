<template>
  <div>
    <MonHistoire />
    <ContactEnd />
  </div>
</template>

<script>
import MonHistoire from "../components/MonHistoire.vue";
export default {
    layout: "header",
    components: { MonHistoire }
}
</script>
    
<style>

</style>