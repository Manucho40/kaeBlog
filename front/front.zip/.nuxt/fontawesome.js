import Vue from 'vue'
import { library, config } from '@fortawesome/fontawesome-svg-core'
import {
  FontAwesomeLayers,
  FontAwesomeLayersText,
  FontAwesomeIcon
} from '@fortawesome/vue-fontawesome'

import {
  faEnvelope as freeFarFaEnvelope
} from '@fortawesome/free-regular-svg-icons'

import {
  faFacebook as freeFabFaFacebook,
  faFacebookF as freeFabFaFacebookF,
  faFacebookMessenger as freeFabFaFacebookMessenger,
  faInstagram as freeFabFaInstagram,
  faTwitter as freeFabFaTwitter,
  faWhatsapp as freeFabFaWhatsapp,
  faPinterest as freeFabFaPinterest,
  faTelegramPlane as freeFabFaTelegramPlane
} from '@fortawesome/free-brands-svg-icons'

library.add(
  freeFarFaEnvelope,
  freeFabFaFacebook,
  freeFabFaFacebookF,
  freeFabFaFacebookMessenger,
  freeFabFaInstagram,
  freeFabFaTwitter,
  freeFabFaWhatsapp,
  freeFabFaPinterest,
  freeFabFaTelegramPlane
)

config.autoAddCss = false

Vue.component('FontAwesomeIcon', FontAwesomeIcon)
Vue.component('FontAwesomeLayers', FontAwesomeLayers)
Vue.component('FontAwesomeLayersText', FontAwesomeLayersText)
