import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _320b0bdc = () => interopDefault(import('..\\pages\\apropos.vue' /* webpackChunkName: "pages/apropos" */))
const _3cea0524 = () => interopDefault(import('..\\pages\\blog\\index.vue' /* webpackChunkName: "pages/blog/index" */))
const _5b162d4a = () => interopDefault(import('..\\pages\\projets.vue' /* webpackChunkName: "pages/projets" */))
const _40bf008c = () => interopDefault(import('..\\pages\\blog\\_id.vue' /* webpackChunkName: "pages/blog/_id" */))
const _6fe2e2f4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/apropos",
    component: _320b0bdc,
    name: "apropos"
  }, {
    path: "/blog",
    component: _3cea0524,
    name: "blog"
  }, {
    path: "/projets",
    component: _5b162d4a,
    name: "projets"
  }, {
    path: "/blog/:id",
    component: _40bf008c,
    name: "blog-id"
  }, {
    path: "/",
    component: _6fe2e2f4,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
