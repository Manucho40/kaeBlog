export const ApercuMoi = () => import('../..\\components\\ApercuMoi.vue' /* webpackChunkName: "components/apercu-moi" */).then(c => wrapFunctional(c.default || c))
export const AprecuArticles = () => import('../..\\components\\AprecuArticles.vue' /* webpackChunkName: "components/aprecu-articles" */).then(c => wrapFunctional(c.default || c))
export const CardArticle = () => import('../..\\components\\CardArticle.vue' /* webpackChunkName: "components/card-article" */).then(c => wrapFunctional(c.default || c))
export const ContactEnd = () => import('../..\\components\\ContactEnd.vue' /* webpackChunkName: "components/contact-end" */).then(c => wrapFunctional(c.default || c))
export const DernierArticle = () => import('../..\\components\\DernierArticle.vue' /* webpackChunkName: "components/dernier-article" */).then(c => wrapFunctional(c.default || c))
export const MonHistoire = () => import('../..\\components\\MonHistoire.vue' /* webpackChunkName: "components/mon-histoire" */).then(c => wrapFunctional(c.default || c))
export const Separateur = () => import('../..\\components\\Separateur.vue' /* webpackChunkName: "components/separateur" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
