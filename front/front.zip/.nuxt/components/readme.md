# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ApercuMoi>` | `<apercu-moi>` (components/ApercuMoi.vue)
- `<AprecuArticles>` | `<aprecu-articles>` (components/AprecuArticles.vue)
- `<CardArticle>` | `<card-article>` (components/CardArticle.vue)
- `<ContactEnd>` | `<contact-end>` (components/ContactEnd.vue)
- `<DernierArticle>` | `<dernier-article>` (components/DernierArticle.vue)
- `<MonHistoire>` | `<mon-histoire>` (components/MonHistoire.vue)
- `<Separateur>` | `<separateur>` (components/Separateur.vue)
